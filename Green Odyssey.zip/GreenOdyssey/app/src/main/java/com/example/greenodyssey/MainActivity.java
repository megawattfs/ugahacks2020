package com.example.greenodyssey;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    private Button quizButton, diaryButton, infoButton, aboutButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        quizButton = (Button)findViewById(R.id.quiz_button);
        diaryButton = (Button)findViewById(R.id.diary_button);
        infoButton = (Button)findViewById(R.id.info_button);
        aboutButton = (Button)findViewById(R.id.about_button);

    }

    public void onClickQuiz(View v) {
        Intent intent = new Intent(MainActivity.this, QuizActivity.class);
        startActivity(intent);
    }
    public void onClickDiary(View v) {
        Intent intent = new Intent(MainActivity.this, QuizActivity.class);
        startActivity(intent);
    }
    public void onClickInfo(View v) {
        Intent intent = new Intent(MainActivity.this, QuizActivity.class);
        startActivity(intent);
    }
    public void onClickAbout(View v) {
        Intent intent = new Intent(MainActivity.this, QuizActivity.class);
        startActivity(intent);
    }
}
